# NEET Zero to Hero

A free, mobile-friendly, single-page NEET study website prototype.

## Run it locally
Open `index.html` in a modern browser. No installation, server, account, API key, or paid service is required.

## Publish online for free with GitHub Pages
1. Sign in to GitHub and create a new **public** repository (for example `neet-zero-to-hero`).
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under build/deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the site. The public URL will be shown in the Pages settings.

Alternative: use Netlify's manual deploy by uploading the folder containing `index.html` in its deploy interface. Review the provider's current free-tier terms before publishing.

## What's included
- Physics, Chemistry and Biology beginner lessons
- Original starter MCQs with explanations
- 10-question, 10-minute mini mock test
- Practice accuracy, answered/correct counts, lesson completion
- Daily checklist
- Browser-local progress using `localStorage`
- Responsive layout for phone and desktop

## Important limitations
- This is a starter website, not an official NEET/NTA or NEETprep product.
- Questions are original practice items, not official previous-year questions.
- Progress is stored in the current browser only; it does not sync between devices and may be lost if browser data is cleared.
- The starter content is limited and should be expanded and checked against the current official NTA syllabus and NCERT textbooks before relying on it for full exam preparation.
- No login, cloud database, teacher/admin panel, or remote analytics is included.
